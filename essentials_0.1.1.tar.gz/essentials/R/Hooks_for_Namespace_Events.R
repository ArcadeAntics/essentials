.onUnload <- function (libpath)
{
    library.dynam.unload("essentials", libpath)
}
