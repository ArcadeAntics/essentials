testing <- function (...)
.Call(C_testing, environment())
