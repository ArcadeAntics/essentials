delayedAssign("os.windows", .Platform$OS.type == "windows")
