tryExcept <- function (expr, ..., finally)
.Defunct()
