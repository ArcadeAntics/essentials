assign.in.place <- function (x, value)
.External2(.C_assigninplace, x, value)
