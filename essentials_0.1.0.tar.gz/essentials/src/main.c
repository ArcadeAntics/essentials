#include <R.h>
#include <Rinternals.h>
#include <Rdefines.h>
#include <Rmath.h>


#define Int2Real(i) ((i == NA_INTEGER) ? NA_REAL : (double)i)


SEXP as_scalar_logical(SEXP x)
{
    return ScalarLogical(asLogical(x));
}


SEXP as_scalar_integer(SEXP x)
{
    return ScalarInteger(asInteger(x));
}


SEXP as_scalar_real(SEXP x)
{
    return ScalarReal(asReal(x));
}


SEXP as_scalar_complex(SEXP x)
{
    return ScalarComplex(asComplex(x));
}


SEXP as_scalar_number(SEXP x, SEXP strict)
{
    switch(TYPEOF(x)) {
    case LGLSXP: case INTSXP: case REALSXP: return as_scalar_real(x);
    default:
        if (asLogical(strict)) {
            Rcomplex value = asComplex(x);
            if (ISNAN(value.r) || ISNAN(value.i))
                return ScalarReal(NA_REAL);
            else if (value.i == 0)
                return ScalarReal(value.r);
            else return ScalarComplex(value);
        }
        return as_scalar_complex(x);
    }
}


SEXP as_scalar_string(SEXP x)
{
    return ScalarString(asChar(x));
}


SEXP as_scalar(SEXP x)
{
    switch(TYPEOF(x)) {
    case LGLSXP: return as_scalar_logical(x);
    case INTSXP: return as_scalar_integer(x);
    case REALSXP: return as_scalar_real(x);
    case CPLXSXP: return as_scalar_complex(x);
    default: return as_scalar_string(x);
    }
}





SEXP as_numbers(SEXP x, SEXP strict)
{
    SEXP value;
    switch(TYPEOF(x)) {
    case LGLSXP: case INTSXP: value = PROTECT(coerceVector(x, REALSXP)); break;
    case REALSXP: case CPLXSXP: value = PROTECT(Rf_duplicate(x)); break;
    default: value = PROTECT(coerceVector(x, CPLXSXP)); break;
    }
    if (ATTRIB(value) != R_NilValue) {
        SET_ATTRIB(value, R_NilValue);
        if (OBJECT(value)) SET_OBJECT(value, 0);
        if (IS_S4_OBJECT(value)) UNSET_S4_OBJECT(value);
    }
    if (TYPEOF(value) == CPLXSXP && asLogical(strict)) {
        int coerce = 1;
        Rcomplex c, *cvalue = COMPLEX(value);
        R_xlen_t i, len = xlength(value);
        for (i = 0; i < len; i++) {
            c = cvalue[i];
            if (!(ISNAN(c.r) || ISNAN(c.i) || c.i == 0)) {
                coerce = 0;
                break;
            }
        }
        if (coerce) {
            UNPROTECT(1);
            return coerceVector(value, REALSXP);
        }
    }
    UNPROTECT(1);
    return value;
}





// since abandoned in favour of 'phypot' (parallel hypotenuse).
//
// 'phypot' has some advantages including:
// * taking any number of arguments (whereas 'hypot_vectorized takes exactly 2)
// * adds an 'na.rm' option
// * a warning is issued when fractional argument recycling
//
// 'phypot' has some changes:
// * complex vectors do not lose their imaginary components
// * character vectors issue an error instead of coercing
SEXP hypot_vectorized(SEXP x, SEXP y)
{
    SEXP value;
    R_xlen_t lenx, leny, len, i;

    lenx = xlength(x);
    leny = xlength(y);
    if (lenx == 0 || leny == 0) return allocVector(REALSXP, 0);

    x = PROTECT(coerceVector(x, REALSXP));
    y = PROTECT(coerceVector(y, REALSXP));

    len = fmax2(lenx, leny);
    value = PROTECT(allocVector(REALSXP, len));
    double *rx = REAL(x), *ry = REAL(y), *rvalue = REAL(value);

    for (i = 0; i < len; i++) {
        rvalue[i] = hypot(rx[i % lenx], ry[i % leny]);
    }

    UNPROTECT(3);
    return value;
}


#define hypot_Rcomplex(X) hypot(X.r, X.i)
#define ISNAN_Rcomplex(X) (ISNAN(X.r) || ISNAN(X.i))


// updates 'value' to be the parallel hypotenuse of 'value' and 'x'
void phypot4(double *value, SEXP x, R_xlen_t len, int na_rm)
{
    R_xlen_t i, lenx = xlength(x);
    if (lenx == 0) {
        error("internal error, 'x' should not be length 0");
        return;
    }
    switch(TYPEOF(x)) {
    case INTSXP:
    case LGLSXP:
    {
        int *ix = INTEGER(x);
        if (lenx == 1) { // 'x' is a scalar
            int x1 = ix[0];

            // if 'x' is 0 or would be removed by 'na.rm'
            if (x1 == 0 || (na_rm && x1 == NA_INTEGER))
                return;

            double rx1 = Int2Real(x1);
            for (i = 0; i < len; i++) {
                value[i] = hypot(value[i], rx1);
            }
        }
        else if (lenx == len) {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (ix[i] != NA_INTEGER)
                        value[i] = hypot(value[i], Int2Real(ix[i]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], Int2Real(ix[i]));
                }
            }
        }
        else {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (ix[i % len] != NA_INTEGER)
                        value[i] = hypot(value[i], Int2Real(ix[i % len]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], Int2Real(ix[i % len]));
                }
            }
        }
    }
        break;
    case REALSXP:
    {
        double *rx = REAL(x);
        if (lenx == 1) { // 'x' is a scalar
            double x1 = rx[0];

            // if 'x' is 0 or would be removed by 'na.rm'
            if (x1 == 0 || (na_rm && ISNAN(x1)))
                return;

            for (i = 0; i < len; i++) {
                value[i] = hypot(value[i], x1);
            }
        }
        else if (lenx == len) {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (!ISNAN(rx[i]))
                        value[i] = hypot(value[i], rx[i]);
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], rx[i]);
                }
            }
        }
        else {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (!ISNAN(rx[i % len]))
                        value[i] = hypot(value[i], rx[i % len]);
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], rx[i % len]);
                }
            }
        }
    }
        break;
    case CPLXSXP:
    {
        Rcomplex *cx = COMPLEX(x);
        if (lenx == 1) { // 'x' is a scalar
            Rcomplex x1 = cx[0];
            double rx1 = hypot_Rcomplex(x1);

            // if 'x' is 0 or would be removed by 'na.rm'
            if (rx1 == 0 || (na_rm && ISNAN_Rcomplex(x1)))
                return;

            for (i = 0; i < len; i++) {
                value[i] = hypot(value[i], hypot_Rcomplex(x1));
            }
        }
        else if (lenx == len) {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (!ISNAN_Rcomplex(cx[i]))
                        value[i] = hypot(value[i], hypot_Rcomplex(cx[i]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], hypot_Rcomplex(cx[i]));
                }
            }
        }
        else {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (!ISNAN_Rcomplex(cx[i % len]))
                        value[i] = hypot(value[i], hypot_Rcomplex(cx[i % len]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], hypot_Rcomplex(cx[i % len]));
                }
            }
        }
    }
        break;
    default:
        error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
    }
}


// upgraded version of 'hypot_vectorized'
SEXP phypot(SEXP args)
{
    SEXP a, x;
    R_xlen_t n, len = 1;
    int na_rm;

    // when using .External, the "ExternalRoutine" is included in 'args'
    // use 'CDR' to remove this
    args = CDR(args);

    // 'na.rm' is the first value in 'args', use 'CAR' to select it
    na_rm = asLogical(CAR(args));

    // rest of 'args'
    args = CDR(args);

    // if there are no arguments, return numeric(0)
    if (args == R_NilValue) return allocVector(REALSXP, 0);

    // n is the length of the current vector
    // len will be the length of the resultant vector
    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
        if (len) {
            n = xlength(x);
            len = (n == 0) ? n : ((len < n) ? n : len);
        }
    }

    if (len == 0) return allocVector(REALSXP, 0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        n = xlength(CAR(a));
        if (len % n) {
            warning("an argument will be fractionally recycled");
            break;
        }
    }

    SEXP value = PROTECT(allocVector(REALSXP, len));
    double *rvalue = REAL(value);
    memset(rvalue, 0, len * sizeof(double));

    for (a = args; a != R_NilValue; a = CDR(a)) {
        phypot4(rvalue, CAR(a), len, na_rm);
    }

    UNPROTECT(1);
    return value;
}


void do_hypot3(double *value, SEXP x, Rboolean na_rm)
{
    R_xlen_t i, len = xlength(x);

    switch(TYPEOF(x)) {
    case INTSXP:
    case LGLSXP:
    {
        int *ix = INTEGER(x);
        if (na_rm) {
            for (i = 0; i < len; i++) {
                if (ix[i] != NA_INTEGER)
                    *value = hypot(*value, Int2Real(ix[i]));
            }
        }
        else {
            for (i = 0; i < len; i++) {
                *value = hypot(*value, Int2Real(ix[i]));
            }
        }
    }
        break;
    case NILSXP:
        break;
    case REALSXP:
    {
        double *rx = REAL(x);
        if (na_rm) {
            for (i = 0; i < len; i++) {
                if (!ISNAN(rx[i]))
                    *value = hypot(*value, rx[i]);
            }
        }
        else {
            for (i = 0; i < len; i++) {
                *value = hypot(*value, rx[i]);
            }
        }
    }
        break;
    case CPLXSXP:
    {
        Rcomplex *cx = COMPLEX(x);
        if (na_rm) {
            for (i = 0; i < len; i++) {
                if (!ISNAN_Rcomplex(cx[i]))
                    *value = hypot(*value, hypot_Rcomplex(cx[i]));
            }
        }
        else {
            for (i = 0; i < len; i++) {
                *value = hypot(*value, hypot_Rcomplex(cx[i]));
            }
        }
    }
        break;
    default:
        error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
    }
}


SEXP do_hypot(SEXP args)
{
    SEXP a, x;
    int na_rm;

    args = CDR(args);
    na_rm = asLogical(CAR(args));
    args = CDR(args);

    // if there are no arguments, return 0
    if (args == R_NilValue) return ScalarReal(0.0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
    }

    double value = 0.0;
    for (a = args; a != R_NilValue; a = CDR(a)) {
        do_hypot3(&value, CAR(a), na_rm);
    }
    return ScalarReal(value);
}





static const R_CallMethodDef callRoutines[] = {
    {"as.scalar.logical", (DL_FUNC) &as_scalar_logical, 1},
    {"as.scalar.integer", (DL_FUNC) &as_scalar_integer, 1},
    {"as.scalar.real"   , (DL_FUNC) &as_scalar_real   , 1},
    {"as.scalar.complex", (DL_FUNC) &as_scalar_complex, 1},
    {"as.scalar.number" , (DL_FUNC) &as_scalar_number , 2},
    {"as.scalar.string" , (DL_FUNC) &as_scalar_string , 1},
    {"as.scalar"        , (DL_FUNC) &as_scalar        , 1},
    {"as.numbers"       , (DL_FUNC) &as_numbers       , 2},

    // {"hypot"            , (DL_FUNC) &hypot_vectorized , 2},

    {NULL, NULL, 0}
};


static const R_ExternalMethodDef externalRoutines[] = {
    {"do_hypot", (DL_FUNC) &do_hypot, -1},
    {"phypot"  , (DL_FUNC) &phypot  , -1},
    {NULL, NULL, 0}
};


void R_init_essentials(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, callRoutines, NULL, externalRoutines);
    R_useDynamicSymbols(dll, FALSE);
    R_forceSymbols(dll, TRUE);
}
