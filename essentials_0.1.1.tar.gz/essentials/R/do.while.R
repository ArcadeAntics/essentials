do <- function (x)
x


`%while%` <- function (expr, cond)
{
    expr <- substitute(expr)
    if (!is.call(expr) || !identical(expr[[1L]], as.symbol("do")))
        stop("do while loop must begin with 'do'")
    else if (length(expr) != 2L)
        stop("invalid 'expr'")
    expr <- expr[[2L]]

    cond <- substitute(cond)
    if (!is.call(cond) || !identical(cond[[1L]], as.symbol("(")))
        stop("'cond' must be wrapped with parenthesis")
    else if (length(cond) != 2L)
        stop("invalid 'cond'")
    cond <- cond[[2L]]

    do.while(expr, cond)
}


`%until%` <- function (expr, cond)
{
    expr <- substitute(expr)
    if (!is.call(expr) || !identical(expr[[1L]], as.symbol("do")))
        stop("do until loop must begin with 'do'")
    else if (length(expr) != 2L)
        stop("invalid 'expr'")
    expr <- expr[[2L]]

    cond <- substitute(cond)
    if (!is.call(cond) || !identical(cond[[1L]], as.symbol("(")))
        stop("'cond' must be wrapped with parenthesis")
    else if (length(cond) != 2L)
        stop("invalid 'cond'")
    cond <- call("!", cond[[2L]])

    do.while(expr, cond)
}


do.while <- function (expr, cond)
{
    ## Since we have to evaluate the code block 'expr' once
    ## before evaluating the condition 'cond', it means it
    ## will be evaluated OUTSIDE a loop. The issue with this
    ## is that the control statements 'break' and 'next'
    ## will not behave as intended. We get around this by
    ## evaluating 'expr' inside a loop that will only be
    ## evaluated once that will keep track of whether either
    ## of these control statements are used.
    ##
    ## First, in the condition, we will use variable '.next'
    ## to keep track of how many times the condition has
    ## been evaluated. When the value of '.next' is greater
    ## than 1, we know a 'next' control statement was used.
    ##
    ## In the expression, we will use variable '.break' to
    ## determine if a 'break' control statement was used. We
    ## will assume that a 'break' control statement will be
    ## used, evaluate the original expression 'expr', and
    ## then lastly we will change the value of '.break' to
    ## FALSE and exit with 'break'. Since we are using our
    ## own break, it means '.next' won't be updated by
    ## accident, it will ONLY be updated when a next is
    ## used.
    ##
    ## Since we will be evaluating this second condition and
    ## expresssion in the user's context, we need to use the
    ## triple colon operator as well as assignInNamespace.

    # cond2 <- quote({
    #     utils::assignInNamespace(".next", value = c(essentials:::.next[[1L]] +
    #         1L, essentials:::.next[-1L]), ns = "essentials")
    #     essentials:::.next[[1L]] < 2L
    # })

    cond2 <- call("{", as.call(list(call("::", as.symbol("utils"),
        as.symbol("assignInNamespace")), ".next", value = call("c",
        call("+", call("[[", call(":::", as.symbol("essentials"),
            as.symbol(".next")), 1L), 1L), call("[", call(":::",
            as.symbol("essentials"), as.symbol(".next")), -1L)),
        ns = "essentials")), call("<", call("[[", call(":::",
        as.symbol("essentials"), as.symbol(".next")), 1L), 2L))

    expr2 <- expr
    if (!inherits(expr2, "{"))
        expr2 <- call("{", expr2)

    # expr2 <- as.call(c(
    #     as.list(expr2),
    #     quote(utils::assignInNamespace(".break", value = c(FALSE, essentials:::.break[-1L]), ns = "essentials")),
    #     call("break"))
    # )

    expr2 <- as.call(c(
        as.list(expr2),
        as.call(list(call("::", as.symbol("utils"), as.symbol("assignInNamespace")),
            ".break", value = call("c", FALSE, call("[", call(":::",
                as.symbol("essentials"), as.symbol(".break")),
                -1L)), ns = "essentials")),
        call("break"))
    )

    ## we initialize '.break' and '.next' assuming that the
    ## loop will be broken and that the number of times the
    ## condition has been evaluated to zero.
    ##
    ## '.break' will be set to FALSE if the loop is not
    ## broken.
    ##
    ## '.next' will increase each time the condition is
    ## evaluated. This means if it is greater than 1, a
    ## 'next' was used.

    assignInMyNamespace(".break", c(TRUE, .break))
    on.exit(assignInMyNamespace(".break", .break[-1L]))
    assignInMyNamespace(".next", c(0L, .next))
    on.exit(assignInMyNamespace(".next", .next[-1L]), add = TRUE)

    ## evaluate the expression before the condition using
    ## the safe method described above.

    envir <- parent.frame(2)
    eval(bquote(while (.(cond2)) .(expr2)), envir = envir)

    ## if 'next' was used above or if 'break' was not used
    if (.next[[1L]] >= 2L || !.break[[1L]])
        eval(bquote(while (.(cond)) .(expr)), envir = envir)
}


.break <- logical(0)
.next <- integer(0)
