seq2 <- function (from, to, by, length.out, along.with, endpoint, ...)
.Call(C_seq, environment())
