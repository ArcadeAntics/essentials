.write.code <- function (...)
.Defunct("this.path:::.write.code()")
