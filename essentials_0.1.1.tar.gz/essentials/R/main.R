methods::setClassUnion(
    name = "numbers",
    members = c("numeric", "complex")
)


methods::setMethod(
    f = "coerce",
    signature = c(from = "ANY", to = "numbers"),
    definition = function (from, to, strict = TRUE)
{
    value <- as.numbers(from)
    if (strict)
        attributes(value) <- NULL
    value
})


as.scalar.logical <- function (x)
.Call(C_as.scalar.logical, x)


as.scalar.integer <- function (x)
.Call(C_as.scalar.integer, x)


as.scalar.real <- as.scalar.double <- as.scalar.numeric <- function (x)
.Call(C_as.scalar.real, x)


as.scalar.complex <- function (x)
.Call(C_as.scalar.complex, x)


as.scalar.number <- function (x, strict = TRUE)
.Call(C_as.scalar.number, x, strict)


as.scalar.string <- as.scalar.character <- function (x)
.Call(C_as.scalar.string, x)


as.scalar <- function (x)
.Call(C_as.scalar, x)


aslength1 <- function (x)
{
    if (!is.vector(x))
        x <- as.vector(x)
    len <- length(x)
    if (len == 1L) {
        x
    }
    else if (len > 1L) {
        warning(gettextf("first element used of '%s' argument",
            deparse(substitute(x), nlines = 1L)[1L], domain = NA))
        x[1L]
    }
    else stop(gettextf("'%s' must be of length 1", domain = NA,
        deparse(substitute(x), nlines = 1L)[1L]))
}





numbers <- function (length = 0L)
numeric(length = length)


as.numbers <- function (x, ...)
UseMethod("as.numbers")


as.numbers.default <- function (x, strict = TRUE, ...)
.Call(C_as.numbers, if (missing(x)) NULL else x, strict)


is.numbers <- function (x)
UseMethod("is.numbers")


is.numbers.default <- function (x)
is.numeric(x) || is.complex(x)





flat.list <- function (...)
{
    value <- list()
    i <- 0L
    names(value) <- names(rapply(list(...), f = function(X) {
        i <<- i + 1L
        value[[i]] <<- X
        NA
    }))
    return(value)
}


# hypot <- function (x, y)
# {
#     if (missing(y))
#         .Call(C_hypot, Re(x), Im(x))
#     else .Call(C_hypot, x, y)
# }


hypot <- function (..., na.rm = FALSE)
.External(C_hypot, na.rm, ...)


phypot <- function (..., na.rm = FALSE)
.External(C_phypot, na.rm, ...)


listify <- function (x)
if (inherits(x, "list")) x else list(x)


strip <- function (x)
gsub("^\\s+|\\s+$", "", x)



formals2 <- function (fun = sys.function(sys.parent()), envir = parent.frame())
{
    # a little bit of sneaky work is needed to get the formal arguments of a
    #     primitive function
    # if you take a look at:
    #
    # ?base::formals
    #
    # you'll see that primitive functions have no formal arguments
    #
    # try for yourself:
    #
    # is.primitive(base::sum)
    # formals(base::sum)
    #
    # so what we have to do is create a temporary file, use 'sink' to write
    #     the output of 'print' into that file, and then parse and evaluate
    #     it using 'source'

    if (is.character(fun))
        fun <- get(fun, mode = "function", envir = envir)
    if (is.primitive(fun)) {
        tmp <- tempfile()
        on.exit(suppressWarnings(file.remove(tmp)))
        sink(file = tmp)
        print(fun)
        sink()
        fun <- source(file = tmp, local = TRUE, echo = FALSE,
            print.eval = FALSE, verbose = FALSE)$value
        if (is.primitive(fun))
            warning(gettextf("cannot retrieve formal arguments for primitive function '%s'",
                deparse(fun), domain = NA))
    }
    formals(fun)
}


wrapper <- function (fun, defaults = NULL)
{
    pkg <- NULL
    ns.accessor <- "::"
    fun <- substitute(fun)
    if (is.call(fun)) {
        do ({
            if (is.symbol(fun[[1L]]) && as.character(fun[[1L]]) %in% c("::", ":::")) {
                ns.accessor <- as.character(fun[[1L]])
                pkg <- as.character(fun[[2L]])
                fun <- as.character(fun[[3L]])
            }
            else fun <- fun[[1L]]
        }) %until% (is.character(fun))
    }
    else fun <- as.character(fun)
    if (is.null(pkg)) {
        x <- get(fun, mode = "function", envir = parent.frame())
        envir <- parent.frame()
        while (!identical(envir, emptyenv())) {
            if (exists(fun, mode = "function", envir, inherits = FALSE)) {
                if (identical(envir, baseenv())) {
                    pkg <- "base"
                    break
                }
                name <- attr(envir, "name")
                if (!is.null(name) && grepl("^package:", name) && !is.null(attr(envir, "path")))
                    pkg <- .rmpkg(name)
                break
            }
            envir <- parent.env(envir)
        }
    }
    else if (identical(ns.accessor, "::")) {
        x <- getExportedValue(pkg, fun)
        if (mode(x) != "function")
            stop(gettextf("'%s' is not an exported function from 'namespace:%s'",
                fun, pkg), domain = NA)
    }
    else {
        x <- get(fun, mode = "function",
            envir = asNamespace(pkg), inherits = FALSE)
    }
    x <- names(formals2(x))
    y <- lapply(x, "as.symbol")
    x[x == "..."] <- ""
    names(y) <- x
    if (is.list(defaults)) {
        if (!is.null(names(defaults)))
            y[names(defaults)] <- defaults
        else y[seq_along(defaults)] <- defaults
    }
    if (is.null(pkg))
        as.call(c(as.symbol(fun), y))
    else as.call(c(call(ns.accessor, as.symbol(pkg), as.symbol(fun)), y))
}
