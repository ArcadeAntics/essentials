seq2 <- function (from, to, by, length.out, along.with, endpoint, ...)
.External2(.C_seq2)
