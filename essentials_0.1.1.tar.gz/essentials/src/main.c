#include <R.h>
#include <Rinternals.h>





// convert an integer to a real number
#define Int2Real(X) ((X == NA_INTEGER) ? NA_REAL : (double) X)

// remove all attributes from 'X'
#define remove_attrib(X)                                       \
    if (ATTRIB(X) != R_NilValue) {                             \
        SET_ATTRIB(X, R_NilValue);                             \
        if (OBJECT(X)) SET_OBJECT(X, 0);                       \
        if (IS_S4_OBJECT(X)) UNSET_S4_OBJECT(X);               \
    }                                                          \

// hypotenuse of a complex number
#define chypot1(X) hypot2(X.r, X.i)

// test if a complex number is NA
#define cISNAN(X) (ISNAN(X.r) || ISNAN(X.i))

// test if a complex number is purely real
#define purelyReal(X) (cISNAN(X) || X.i == 0.0)





// version of 'hypot' which should return NA_real_ where appropriate
double hypot2(double x, double y)
{
    double value = hypot(x, y);
    if (!ISNAN(value) || (!ISNA(x) && !ISNA(y))) return value;
    return NA_REAL;
}


// version of 'hypot2' that handles a complex valued 'y'
double chypot2(double x, Rcomplex y)
{
    return hypot2(x, chypot1(y));
}





SEXP asScalarLogical(SEXP x)
{
    return ScalarLogical(asLogical(x));
}


SEXP asScalarInteger(SEXP x)
{
    return ScalarInteger(asInteger(x));
}


SEXP asScalarReal(SEXP x)
{
    return ScalarReal(asReal(x));
}


SEXP asScalarComplex(SEXP x)
{
    return ScalarComplex(asComplex(x));
}


SEXP asScalarNumber(SEXP x, SEXP strict)
{
    switch(TYPEOF(x)) {
    case NILSXP:
    case LGLSXP:
    case INTSXP:
    case REALSXP:
        return asScalarReal(x);
    default:
        if (asLogical(strict)) {
            Rcomplex value = asComplex(x);
            if (cISNAN(value))
                return ScalarReal(NA_REAL);
            else if (value.i == 0)
                return ScalarReal(value.r);
            else return ScalarComplex(value);
        }
        return asScalarComplex(x);
    }
}


SEXP asScalarString(SEXP x)
{
    return ScalarString(asChar(x));
}


SEXP asScalar(SEXP x)
{
    switch(TYPEOF(x)) {
    case LGLSXP: return asScalarLogical(x);
    case INTSXP: return asScalarInteger(x);
    case REALSXP: return asScalarReal(x);
    case CPLXSXP: return asScalarComplex(x);
    default: return asScalarString(x);
    }
}





SEXP as_numbers(SEXP x, SEXP strict)
{
    SEXP value;

    switch(TYPEOF(x)) {
    case LGLSXP:
    case INTSXP:
        value = PROTECT(coerceVector(x, REALSXP));
        remove_attrib(value);
        UNPROTECT(1);
        return value;
    case REALSXP:
    {
        value = PROTECT(Rf_lazy_duplicate(x));
        remove_attrib(value);
        UNPROTECT(1);
        return value;
    }
    case CPLXSXP:
        value = PROTECT(Rf_lazy_duplicate(x));
        break;
    default:
        value = PROTECT(coerceVector(x, CPLXSXP));
        break;
    }

    remove_attrib(value);

    // possible coerce from 'CPLXSXP' to 'REALSXP'
    if (asLogical(strict)) {
        int coerce = 1;
        Rcomplex *cvalue = COMPLEX(value);
        R_xlen_t i, len = xlength(value);
        for (i = 0; i < len; i++) {
            if (!purelyReal(cvalue[i])) {
                coerce = 0;
                break;
            }
        }
        if (coerce) {
            UNPROTECT(1);
            return coerceVector(value, REALSXP);
        }
    }

    UNPROTECT(1);
    return value;
}





// since abandoned in favour of 'phypot' (parallel "hypotenuse").
//
// 'phypot' has some advantages including:
// * taking any number of arguments (whereas 'hypot_vectorized' takes exactly 2)
// * adds an 'na.rm' option
// * a warning is issued when fractional argument recycling occurs
// * 'dim', 'dimnames' and 'names' attributes are copied to return value when appropriate
//
// 'phypot' has some changes:
// * complex vectors do not lose their imaginary components
// * character vectors issue an error instead of coercing
SEXP hypot_vectorized(SEXP x, SEXP y)
{
    SEXP value;
    R_xlen_t lenx, leny, len, i;

    lenx = xlength(x);
    leny = xlength(y);
    if (lenx == 0 || leny == 0) return allocVector(REALSXP, 0);

    x = PROTECT(coerceVector(x, REALSXP));
    y = PROTECT(coerceVector(y, REALSXP));

    len = fmax(lenx, leny);
    value = PROTECT(allocVector(REALSXP, len));
    double *rx = REAL(x), *ry = REAL(y), *rvalue = REAL(value);

    for (i = 0; i < len; i++) {
        rvalue[i] = hypot2(rx[i % lenx], ry[i % leny]);
    }

    UNPROTECT(3);
    return value;
}





/* old version of 'phypot'

// updates 'value' to be the parallel "hypotenuse" of 'value' and 'x'
void phypot4(double *value, SEXP x, R_xlen_t len, int na_rm)
{
    R_xlen_t i, lenx = xlength(x);
    if (lenx == 0) {
        error("internal error, 'x' should not be length 0");
        return;
    }
    switch(TYPEOF(x)) {
    case INTSXP:
    case LGLSXP:
    {
        int *ix = INTEGER(x);
        if (lenx == 1) { // 'x' is a scalar
            int x1 = ix[0];

            // if 'x' is 0 or would be removed by 'na.rm'
            if (x1 == 0 || (na_rm && x1 == NA_INTEGER))
                return;

            double rx1 = Int2Real(x1);
            for (i = 0; i < len; i++) {
                value[i] = hypot(value[i], rx1);
            }
        }
        else if (lenx == len) {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (ix[i] != NA_INTEGER)
                        value[i] = hypot(value[i], Int2Real(ix[i]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], Int2Real(ix[i]));
                }
            }
        }
        else {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (ix[i % len] != NA_INTEGER)
                        value[i] = hypot(value[i], Int2Real(ix[i % len]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], Int2Real(ix[i % len]));
                }
            }
        }
    }
        break;
    case REALSXP:
    {
        double *rx = REAL(x);
        if (lenx == 1) { // 'x' is a scalar
            double x1 = rx[0];

            // if 'x' is 0 or would be removed by 'na.rm'
            if (x1 == 0 || (na_rm && ISNAN(x1)))
                return;

            for (i = 0; i < len; i++) {
                value[i] = hypot(value[i], x1);
            }
        }
        else if (lenx == len) {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (!ISNAN(rx[i]))
                        value[i] = hypot(value[i], rx[i]);
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], rx[i]);
                }
            }
        }
        else {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (!ISNAN(rx[i % len]))
                        value[i] = hypot(value[i], rx[i % len]);
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], rx[i % len]);
                }
            }
        }
    }
        break;
    case CPLXSXP:
    {
        Rcomplex *cx = COMPLEX(x);
        if (lenx == 1) { // 'x' is a scalar
            Rcomplex x1 = cx[0];
            double rx1 = chypot(x1);

            // if 'x' is 0 or would be removed by 'na.rm'
            if (rx1 == 0 || (na_rm && cISNAN(x1)))
                return;

            for (i = 0; i < len; i++) {
                value[i] = hypot(value[i], chypot(x1));
            }
        }
        else if (lenx == len) {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (!cISNAN(cx[i]))
                        value[i] = hypot(value[i], chypot(cx[i]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], chypot(cx[i]));
                }
            }
        }
        else {
            if (na_rm) {
                for (i = 0; i < len; i++) {
                    if (!cISNAN(cx[i % len]))
                        value[i] = hypot(value[i], chypot(cx[i % len]));
                }
            }
            else {
                for (i = 0; i < len; i++) {
                    value[i] = hypot(value[i], chypot(cx[i % len]));
                }
            }
        }
    }
        break;
    default:
        error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
    }
}


// upgraded version of 'hypot_vectorized'
// n-dimensional parallel "hypotenuse"
SEXP phypot(SEXP args)
{
    SEXP a, x;
    R_xlen_t n, len = 1;
    int na_rm;

    // when using .External, the "ExternalRoutine" is included in 'args'
    // use 'CDR' to remove this
    args = CDR(args);

    // 'na.rm' is the first value in 'args', use 'CAR' to select it
    na_rm = asLogical(CAR(args));

    // rest of 'args'
    args = CDR(args);

    // if there are no arguments, return numeric(0)
    if (args == R_NilValue) return allocVector(REALSXP, 0);

    // n is the length of the current vector
    // len will be the length of the resultant vector
    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
        if (len) {
            n = xlength(x);
            len = (n == 0) ? n : ((len < n) ? n : len);
        }
    }

    if (len == 0) return allocVector(REALSXP, 0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        n = xlength(CAR(a));
        if (len % n) {
            warning("an argument will be fractionally recycled");
            break;
        }
    }

    SEXP value = PROTECT(allocVector(REALSXP, len));
    double *rvalue = REAL(value);
    memset(rvalue, 0.0, len * sizeof(double));

    for (a = args; a != R_NilValue; a = CDR(a)) {
        phypot4(rvalue, CAR(a), len, na_rm);
    }

    // copy 'dim', 'dimnames' and 'names' attributes from appropriate arguments
    for (a = args; a != R_NilValue; a = CDR(a)) {

        x = CAR(a);
        // the argument must be the same length as 'value' in
        // order to copy 'dim', 'dimnames' and 'names' attributes
        if (xlength(x) == len) {

            // if 'value' does not have a 'dim' attribute
            if (getAttrib(value, R_DimSymbol) == R_NilValue) {

                // if 'value' does not have a 'dim' attribute
                // and 'x' has a 'dim' attribute
                if (getAttrib(x, R_DimSymbol) != R_NilValue) {
                    setAttrib(value, R_DimSymbol, getAttrib(x, R_DimSymbol));
                    setAttrib(value, R_NamesSymbol, R_NilValue);

                    // if 'a' also has a 'dimnames' attribute,
                    // copy them and immediately return 'value'
                    if (getAttrib(x, R_DimNamesSymbol) != R_NilValue) {
                        setAttrib(value, R_DimNamesSymbol, getAttrib(x, R_DimNamesSymbol));
                        UNPROTECT(1);
                        return value;
                    }
                }
                else if (getAttrib(value, R_NamesSymbol) == R_NilValue &&
                    getAttrib(x, R_NamesSymbol) != R_NilValue) {
                    setAttrib(value, R_NamesSymbol, getAttrib(x, R_NamesSymbol));
                }
            }
            else if (conformable(value, x)) {
                if (getAttrib(x, R_DimNamesSymbol) != R_NilValue) {
                    setAttrib(value, R_DimNamesSymbol, getAttrib(x, R_DimNamesSymbol));
                    UNPROTECT(1);
                    return value;
                }
            }
        }
    }

    UNPROTECT(1);
    return value;
}
 */





/* old version of 'nhypot'

// updates 'value' to be the n-dimensional "hypotenuse" of 'value' and each element of 'x'
void do_hypot3(double *value, SEXP x, Rboolean na_rm)
{
    R_xlen_t i, len = xlength(x);

    switch(TYPEOF(x)) {
    case INTSXP:
    case LGLSXP:
    {
        int *ix = INTEGER(x);
        if (na_rm) {
            for (i = 0; i < len; i++) {
                if (ix[i] != NA_INTEGER)
                    *value = hypot(*value, Int2Real(ix[i]));
            }
        }
        else {
            for (i = 0; i < len; i++) {
                *value = hypot(*value, Int2Real(ix[i]));
            }
        }
    }
        break;
    case NILSXP:
        break;
    case REALSXP:
    {
        double *rx = REAL(x);
        if (na_rm) {
            for (i = 0; i < len; i++) {
                if (!ISNAN(rx[i]))
                    *value = hypot(*value, rx[i]);
            }
        }
        else {
            for (i = 0; i < len; i++) {
                *value = hypot(*value, rx[i]);
            }
        }
    }
        break;
    case CPLXSXP:
    {
        Rcomplex *cx = COMPLEX(x);
        if (na_rm) {
            for (i = 0; i < len; i++) {
                if (!cISNAN(cx[i]))
                    *value = hypot(*value, chypot(cx[i]));
            }
        }
        else {
            for (i = 0; i < len; i++) {
                *value = hypot(*value, chypot(cx[i]));
            }
        }
    }
        break;
    default:
        error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
    }
}


// n-dimensional "hypotenuse"
SEXP nhypot(SEXP args)
{
    SEXP a, x;
    int na_rm;

    args = CDR(args);
    na_rm = asLogical(CAR(args));
    args = CDR(args);

    // if there are no arguments, return 0
    if (args == R_NilValue) return ScalarReal(0.0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
    }

    double value = 0.0;
    for (a = args; a != R_NilValue; a = CDR(a)) {
        do_hypot3(&value, CAR(a), na_rm);
    }
    return ScalarReal(value);
}
 */





// upgraded version of 'hypot_vectorized'
// n-dimensional parallel "hypotenuse"
SEXP phypot(SEXP args)
{
    SEXP a, x;
    R_xlen_t i, n, len = 1;
    int na_rm;

    // when using the R function '.External' to call a C function,
    // the 'ExternalRoutine' object (argument '.NAME' of '.External')
    // is included in 'args'
    // use 'CDR' to remove this
    args = CDR(args);

    // 'na.rm' is the first value in 'args', use 'CAR' to select it
    na_rm = asLogical(CAR(args));

    // rest of 'args'
    args = CDR(args);

    // if there are no arguments, return numeric(0)
    if (args == R_NilValue) return allocVector(REALSXP, 0);

    // 'n' is the length of the current vector
    // 'len' will be the length of the resultant vector
    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
        if (len) {
            n = xlength(x);
            if (n == 0 || n > len)
                len = n;
        }
    }

    if (len == 0) return allocVector(REALSXP, 0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        if (len % xlength(CAR(a))) {
            warning("an argument will be fractionally recycled");
            break;
        }
    }

    SEXP value = PROTECT(allocVector(REALSXP, len));
    double *rvalue = REAL(value);
    Memzero(rvalue, len);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        n = xlength(x);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        {
            int *ix = INTEGER(x);
            if (n == 1) { // 'x' is a scalar
                int x1 = ix[0];

                // if 'x' is 0 or would be removed by 'na.rm'
                if (x1 == 0 || (na_rm && x1 == NA_INTEGER))
                    continue;

                double rx1 = Int2Real(x1);
                for (i = 0; i < len; i++) {
                    rvalue[i] = hypot2(rvalue[i], rx1);
                }
            }
            else if (n == len) {
                if (na_rm) {
                    for (i = 0; i < len; i++) {
                        if (ix[i] != NA_INTEGER)
                            rvalue[i] = hypot2(rvalue[i], Int2Real(ix[i]));
                    }
                }
                else {
                    for (i = 0; i < len; i++) {
                        rvalue[i] = hypot2(rvalue[i], Int2Real(ix[i]));
                    }
                }
            }
            else {
                if (na_rm) {
                    for (i = 0; i < len; i++) {
                        if (ix[i % len] != NA_INTEGER)
                            rvalue[i] = hypot2(rvalue[i], Int2Real(ix[i % len]));
                    }
                }
                else {
                    for (i = 0; i < len; i++) {
                        rvalue[i] = hypot2(rvalue[i], Int2Real(ix[i % len]));
                    }
                }
            }
        }
            break;
        case REALSXP:
        {
            double *rx = REAL(x);
            if (n == 1) { // 'x' is a scalar
                double x1 = rx[0];

                // if 'x' is 0 or would be removed by 'na.rm'
                if (x1 == 0 || (na_rm && ISNAN(x1)))
                    continue;

                for (i = 0; i < len; i++) {
                    rvalue[i] = hypot2(rvalue[i], x1);
                }
            }
            else if (n == len) {
                if (na_rm) {
                    for (i = 0; i < len; i++) {
                        if (!ISNAN(rx[i]))
                            rvalue[i] = hypot2(rvalue[i], rx[i]);
                    }
                }
                else {
                    for (i = 0; i < len; i++) {
                        rvalue[i] = hypot2(rvalue[i], rx[i]);
                    }
                }
            }
            else {
                if (na_rm) {
                    for (i = 0; i < len; i++) {
                        if (!ISNAN(rx[i % len]))
                            rvalue[i] = hypot2(rvalue[i], rx[i % len]);
                    }
                }
                else {
                    for (i = 0; i < len; i++) {
                        rvalue[i] = hypot2(rvalue[i], rx[i % len]);
                    }
                }
            }
        }
            break;
        case CPLXSXP:
        {
            Rcomplex *cx = COMPLEX(x);
            if (n == 1) { // 'x' is a scalar
                Rcomplex x1 = cx[0];
                double rx1 = chypot1(x1);

                // if 'x' is 0 or would be removed by 'na.rm'
                if (rx1 == 0 || (na_rm && cISNAN(x1)))
                    continue;

                for (i = 0; i < len; i++) {
                    rvalue[i] = hypot2(rvalue[i], rx1);
                }
            }
            else if (n == len) {
                if (na_rm) {
                    for (i = 0; i < len; i++) {
                        if (!cISNAN(cx[i]))
                            rvalue[i] = chypot2(rvalue[i], cx[i]);
                    }
                }
                else {
                    for (i = 0; i < len; i++) {
                        rvalue[i] = chypot2(rvalue[i], cx[i]);
                    }
                }
            }
            else {
                if (na_rm) {
                    for (i = 0; i < len; i++) {
                        if (!cISNAN(cx[i % len]))
                            rvalue[i] = chypot2(rvalue[i], cx[i % len]);
                    }
                }
                else {
                    for (i = 0; i < len; i++) {
                        rvalue[i] = chypot2(rvalue[i], cx[i % len]);
                    }
                }
            }
        }
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
    }

    // copy 'dim', 'dimnames' and 'names' attributes from appropriate arguments
    for (a = args; a != R_NilValue; a = CDR(a)) {

        x = CAR(a);
        // the argument must be the same length as 'value' in
        // order to copy 'dim', 'dimnames' and 'names' attributes
        if (xlength(x) == len) {

            // if 'value' does not have a 'dim' attribute
            if (getAttrib(value, R_DimSymbol) == R_NilValue) {

                // if 'value' does not have a 'dim' attribute
                // and 'x' has a 'dim' attribute
                if (getAttrib(x, R_DimSymbol) != R_NilValue) {

                    // set the 'dim' of 'value' to the 'dim' of 'x'
                    // remove the 'names' of 'value'
                    setAttrib(value, R_DimSymbol, getAttrib(x, R_DimSymbol));
                    setAttrib(value, R_NamesSymbol, R_NilValue);

                    // if 'x' also has a 'dimnames' attribute,
                    // copy them and immediately return 'value'
                    if (getAttrib(x, R_DimNamesSymbol) != R_NilValue) {
                        setAttrib(value, R_DimNamesSymbol, getAttrib(x, R_DimNamesSymbol));
                        UNPROTECT(1);
                        return value;
                    }
                }

                // if 'value' does not have a 'dim' attribute
                // and 'x' does not have a 'dim' attribute
                // and 'value' does not have a 'names' attribute
                // and 'x' has a 'names' attribute
                else if (getAttrib(value, R_NamesSymbol) == R_NilValue &&
                    getAttrib(x, R_NamesSymbol) != R_NilValue) {
                    setAttrib(value, R_NamesSymbol, getAttrib(x, R_NamesSymbol));
                }
            }

            // if 'value' has a 'dim' attribute
            // and 'x' is conformable to 'value' (equivalent 'dim' attribute)
            else if (conformable(value, x)) {

                // if 'x' has a 'dimnames' attribute,
                // copy them and immediately return 'value'
                if (getAttrib(x, R_DimNamesSymbol) != R_NilValue) {
                    setAttrib(value, R_DimNamesSymbol, getAttrib(x, R_DimNamesSymbol));
                    UNPROTECT(1);
                    return value;
                }
            }
        }
    }

    UNPROTECT(1);
    return value;
}


// n-dimensional "hypotenuse"
SEXP nhypot(SEXP args)
{
    SEXP a, x;
    R_xlen_t i, n;
    int na_rm;

    args = CDR(args);
    na_rm = asLogical(CAR(args));
    args = CDR(args);

    // if there are no arguments, return 0
    if (args == R_NilValue) return ScalarReal(0.0);

    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        case NILSXP:
        case REALSXP:
        case CPLXSXP:
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
            return R_NilValue;
        }
    }

    double value = 0.0;
    for (a = args; a != R_NilValue; a = CDR(a)) {
        x = CAR(a);
        n = xlength(x);

        switch(TYPEOF(x)) {
        case INTSXP:
        case LGLSXP:
        {
            int *ix = INTEGER(x);
            if (na_rm) {
                for (i = 0; i < n; i++) {
                    if (ix[i] != NA_INTEGER)
                        value = hypot2(value, Int2Real(ix[i]));
                }
            }
            else {
                for (i = 0; i < n; i++) {
                    value = hypot2(value, Int2Real(ix[i]));
                }
            }
        }
            break;
        case NILSXP:
            break;
        case REALSXP:
        {
            double *rx = REAL(x);
            if (na_rm) {
                for (i = 0; i < n; i++) {
                    if (!ISNAN(rx[i]))
                        value = hypot2(value, rx[i]);
                }
            }
            else {
                for (i = 0; i < n; i++) {
                    value = hypot2(value, rx[i]);
                }
            }
        }
            break;
        case CPLXSXP:
        {
            Rcomplex *cx = COMPLEX(x);
            if (na_rm) {
                for (i = 0; i < n; i++) {
                    if (!cISNAN(cx[i]))
                        value = chypot2(value, cx[i]);
                }
            }
            else {
                for (i = 0; i < n; i++) {
                    value = chypot2(value, cx[i]);
                }
            }
        }
            break;
        default:
            error("invalid 'type' (%s) of argument", type2char(TYPEOF(x)));
        }
    }
    return ScalarReal(value);
}





SEXP testing(SEXP args)
{
    return ScalarInteger((int) NA_LOGICAL);
}





static const R_CallMethodDef callRoutines[] = {
    {"as.scalar.logical", (DL_FUNC) &asScalarLogical, 1},
    {"as.scalar.integer", (DL_FUNC) &asScalarInteger, 1},
    {"as.scalar.real"   , (DL_FUNC) &asScalarReal   , 1},
    {"as.scalar.complex", (DL_FUNC) &asScalarComplex, 1},
    {"as.scalar.number" , (DL_FUNC) &asScalarNumber , 2},
    {"as.scalar.string" , (DL_FUNC) &asScalarString , 1},
    {"as.scalar"        , (DL_FUNC) &asScalar       , 1},
    {"as.numbers"       , (DL_FUNC) &as_numbers     , 2},

    // {"hypot"            , (DL_FUNC) &hypot_vectorized , 2},

    {NULL, NULL, 0}
};


static const R_ExternalMethodDef externalRoutines[] = {
    {"hypot" , (DL_FUNC) &nhypot, -1},
    {"phypot", (DL_FUNC) &phypot, -1},

    {"testing", (DL_FUNC) &testing, -1},

    {NULL, NULL, 0}
};


void R_init_essentials(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, callRoutines, NULL, externalRoutines);
    R_useDynamicSymbols(dll, FALSE);
    R_forceSymbols(dll, TRUE);
}
