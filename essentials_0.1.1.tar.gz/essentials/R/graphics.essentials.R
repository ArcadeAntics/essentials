legend.dimensions <- function (expr, local = TRUE)
{
    envir <- if (isTRUE(local))
        parent.frame()
    else if (isFALSE(local))
        globalenv()
    else if (is.environment(local))
        local
    else stop("'local' must be TRUE, FALSE or an environment")

    if (is.expression(expr))
        expr <- aslength1(expr)[[1L]]
    if (!is.call(expr))
        stop("invalid 'expr', must be a call or expression")

    ## capture the graphical parameters that may affect the legend size
    opar <- par("cex", "family", "font", "lheight",
        mar = rep(0, 4L), xlog = FALSE, ylog = FALSE)

    ## upon exiting, reset the graphical parameters to their original values
    on.exit(par(opar))

    ## do NOT prompt the user before a new page of output is started.
    ## this is intended for use with 'example'
    op <- options(device.ask.default = FALSE)
    on.exit(options(op), add = TRUE, after = FALSE)
    if (.Device != "null device") {
        oldask <- devAskNewPage(ask = FALSE)
        if (oldask)
            on.exit(devAskNewPage(oldask), add = TRUE, after = FALSE)
    }

    filename <- tempfile()

    ## upon exiting, remove the image file 'filename'
    on.exit(suppressWarnings(file.remove(filename)), add = TRUE, after = FALSE)

    odev <- dev.cur()
    on.exit(dev.set(odev), add = TRUE, after = FALSE)

    png(filename = filename, width = 480, height = 480, res = 48)

    cdev <- dev.cur()
    on.exit(dev.off(cdev), add = TRUE, after = FALSE)

    par(opar)
    plot.default(
        xlim = c(0, 10), ylim = c(0, 10), xaxs = "i", yaxs = "i",
        x = NA_real_, y = NA_real_,
        axes = FALSE, frame.plot = FALSE, ann = FALSE
    )
    value <- eval(expr, envir = envir)$rect
    list(w = value$w/xinch(warn.log = FALSE),
         h = value$h/yinch(warn.log = FALSE))
}


show.colors <- function (x)
{
    opar <- par(mar = rep(0, 4L))
    on.exit(par(opar))
    y <- as.matrix(x)
    if (length(y))
        image(x = array(seq_along(y), dim(y)), col = y)
    invisible(x)
}
