# p <- this.path::ArgumentParser(style = 2)
# p$add.argument("--foo", help = "foo help")
# p$add.argument("--bar", help = "bar help for program %(PROGRAM)s")
# p$print.help()
